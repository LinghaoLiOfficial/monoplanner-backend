"""Common backend utility modules."""

