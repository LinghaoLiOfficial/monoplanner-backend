from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv


def load_env_file(env_file: str | Path = ".env", *, override: bool = False) -> bool:
    """Load environment variables from a specific dotenv file."""

    return load_dotenv(Path(env_file), override=override)


def load_project_env(
    start_path: str | Path | None = None,
    *,
    filename: str = ".env",
    override: bool = False,
) -> bool:
    """Search upward from start_path and load the first matching dotenv file."""

    current = Path(start_path or Path.cwd()).resolve()
    if current.is_file():
        current = current.parent

    for directory in (current, *current.parents):
        env_path = directory / filename
        if env_path.exists():
            return load_env_file(env_path, override=override)
    return False

