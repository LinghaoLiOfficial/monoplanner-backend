from __future__ import annotations

import uuid
from collections.abc import Iterator


class IDGenerator:
    """Generate common string identifiers for business code."""

    def __init__(self, snowflake_generator: Iterator[object] | None = None) -> None:
        self.snowflake_generator = snowflake_generator

    def create_uuid4(self) -> str:
        """Create a random UUID4 string."""

        return str(uuid.uuid4())

    def create_snowflake(self) -> str:
        """Create a Snowflake ID string from the configured generator."""

        if self.snowflake_generator is None:
            raise ValueError("snowflake_generator is required to create snowflake IDs.")
        return str(next(self.snowflake_generator))
