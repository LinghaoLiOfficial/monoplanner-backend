from __future__ import annotations

import logging
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from loguru import logger


DEFAULT_CONSOLE_FORMAT = (
    "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
    "<level>{level: <8}</level> | "
    "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
    "<level>{message}</level>"
)
DEFAULT_FILE_FORMAT = (
    "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | "
    "{name}:{function}:{line} - {message}"
)


@dataclass(frozen=True)
class LoggingConfig:
    """Configuration for initializing the project Loguru logging system."""

    level: str = "INFO"
    env: str = "dev"
    log_to_console: bool = True
    log_to_file: bool = False
    file_path: Path | str | None = None
    max_size_mb: int = 10
    backup_days: int = 7
    error_file_level: str = "WARNING"
    error_max_size_mb: int = 10
    error_backup_days: int = 30
    compression: str | None = "zip"
    intercept_loggers: tuple[str, ...] = ("uvicorn", "uvicorn.access", "uvicorn.error", "fastapi")
    console_format: str = DEFAULT_CONSOLE_FORMAT
    file_format: str = DEFAULT_FILE_FORMAT
    colorize_console: bool = True
    serialize_console: bool | None = None
    enqueue_file: bool = True
    diagnose: bool | None = None
    console_sink: Any = sys.stdout

    def __post_init__(self) -> None:
        if self.max_size_mb < 1:
            raise ValueError("max_size_mb must be at least 1.")
        if self.backup_days < 1:
            raise ValueError("backup_days must be at least 1.")
        if self.error_max_size_mb < 1:
            raise ValueError("error_max_size_mb must be at least 1.")
        if self.error_backup_days < 1:
            raise ValueError("error_backup_days must be at least 1.")
        if self.log_to_file and self.file_path is None:
            raise ValueError("file_path is required when log_to_file is True.")


class InterceptHandler(logging.Handler):
    """Forward Python standard logging records to Loguru."""

    def emit(self, record: logging.LogRecord) -> None:
        try:
            level: str | int = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        frame = logging.currentframe()
        depth = 2
        while frame and frame.f_code.co_filename in {logging.__file__, __file__}:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())


def configure_logging(config: LoggingConfig | None = None) -> None:
    """Configure Loguru sinks and intercept selected standard-library loggers."""

    logging_config = config or LoggingConfig()
    logger.remove()

    if logging_config.log_to_console:
        serialize_console = (
            logging_config.env == "prod"
            if logging_config.serialize_console is None
            else logging_config.serialize_console
        )
        logger.add(
            logging_config.console_sink,
            level=logging_config.level,
            format=logging_config.console_format,
            colorize=logging_config.colorize_console and not serialize_console,
            serialize=serialize_console,
        )

    if logging_config.log_to_file:
        file_path = Path(logging_config.file_path)  # type: ignore[arg-type]
        file_path.parent.mkdir(parents=True, exist_ok=True)
        diagnose = logging_config.env != "prod" if logging_config.diagnose is None else logging_config.diagnose

        logger.add(
            str(file_path),
            level=logging_config.level,
            rotation=f"{logging_config.max_size_mb} MB",
            retention=f"{logging_config.backup_days} days",
            compression=logging_config.compression,
            encoding="utf-8",
            enqueue=logging_config.enqueue_file,
            format=logging_config.file_format,
        )
        logger.add(
            str(file_path.with_suffix(".error.log")),
            level=logging_config.error_file_level,
            rotation=f"{logging_config.error_max_size_mb} MB",
            retention=f"{logging_config.error_backup_days} days",
            compression=logging_config.compression,
            encoding="utf-8",
            enqueue=logging_config.enqueue_file,
            format=logging_config.file_format,
            backtrace=True,
            diagnose=diagnose,
        )

    intercept_handler = InterceptHandler()
    logging.basicConfig(handlers=[intercept_handler], level=0, force=True)
    for log_name in logging_config.intercept_loggers:
        std_logger = logging.getLogger(log_name)
        std_logger.handlers = [intercept_handler]
        std_logger.propagate = False

    logger.info("Logger started")
