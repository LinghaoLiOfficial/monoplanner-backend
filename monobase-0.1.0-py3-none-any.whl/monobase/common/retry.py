from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, TypeVar

from tenacity import Retrying, retry_if_exception_type, stop_after_attempt, wait_fixed

T = TypeVar("T")
ExceptionType = type[BaseException] | tuple[type[BaseException], ...]


@dataclass(frozen=True)
class RetryConfig:
    """Configuration for building a synchronous tenacity retry executor."""

    max_attempts: int = 3
    wait_seconds: float = 1.0
    reraise: bool = True

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be at least 1.")
        if self.wait_seconds < 0:
            raise ValueError("wait_seconds must be greater than or equal to 0.")


def get_retry(
    exception: ExceptionType,
    *,
    max_attempts: int = 3,
    wait_seconds: float = 1.0,
    reraise: bool = True,
) -> Retrying:
    """Create a tenacity Retrying executor for the given retryable exception type."""

    config = RetryConfig(max_attempts=max_attempts, wait_seconds=wait_seconds, reraise=reraise)
    return build_retrying(exception, config=config)


def build_retrying(exception: ExceptionType, *, config: RetryConfig | None = None) -> Retrying:
    """Build a tenacity Retrying executor from project-level retry config."""

    retry_config = config or RetryConfig()
    return Retrying(
        stop=stop_after_attempt(retry_config.max_attempts),
        wait=wait_fixed(retry_config.wait_seconds),
        retry=retry_if_exception_type(exception),
        reraise=retry_config.reraise,
    )


def run_with_retry(
    func: Callable[..., T],
    *args: Any,
    exception: ExceptionType = Exception,
    config: RetryConfig | None = None,
    **kwargs: Any,
) -> T:
    """Run a callable with the configured retry behavior."""

    retrying = build_retrying(exception, config=config)
    return retrying(func, *args, **kwargs)
