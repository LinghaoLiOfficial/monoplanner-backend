"""Database module exceptions."""


class DatabaseDependencyError(ImportError):
    """Raised when an optional database driver is not installed."""

