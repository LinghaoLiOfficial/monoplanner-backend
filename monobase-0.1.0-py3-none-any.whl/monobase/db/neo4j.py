from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Literal, overload

from monobase.db.exceptions import DatabaseDependencyError

_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


@dataclass(frozen=True)
class Neo4jConfig:
    """Configuration for Neo4j driver access."""

    uri: str
    auth: tuple[str, str] | None = None
    database: str | None = None
    async_mode: bool = True


def quote_identifier(identifier: str) -> str:
    """Quote a Cypher label/type/property identifier after strict validation."""

    if not _IDENTIFIER_RE.match(identifier):
        raise ValueError(f"Invalid Neo4j identifier: {identifier!r}")
    return f"`{identifier}`"


def create_neo4j_driver(config: Neo4jConfig) -> Any:
    """Create a Neo4j sync or async driver from config."""

    if config.async_mode:
        return create_async_neo4j_driver(config)
    return create_sync_neo4j_driver(config)


def create_sync_neo4j_driver(config: Neo4jConfig) -> Any:
    """Create a Neo4j sync Driver from config."""

    try:
        from neo4j import GraphDatabase
    except ImportError as exc:
        raise DatabaseDependencyError(
            "Neo4j support requires optional dependency: install monobase[db] "
            "or install neo4j."
        ) from exc

    return GraphDatabase.driver(config.uri, auth=config.auth)


def create_async_neo4j_driver(config: Neo4jConfig) -> Any:
    """Create a Neo4j AsyncDriver from config."""

    try:
        from neo4j import AsyncGraphDatabase
    except ImportError as exc:
        raise DatabaseDependencyError(
            "Neo4j support requires optional dependency: install monobase[db] "
            "or install neo4j."
        ) from exc

    return AsyncGraphDatabase.driver(config.uri, auth=config.auth)


class SyncNeo4jRepo:
    """Small generic repository for common Neo4j sync operations."""

    def __init__(self, driver: Any, *, database: str | None = None):
        self.driver = driver
        self.database = database

    def run(self, query: str, parameters: dict[str, Any] | None = None) -> list[Any]:
        """Run a Cypher query and return all records."""

        with self.driver.session(database=self.database) as session:
            result = session.run(query, parameters or {})
            return result.data()

    def execute_write(self, query: str, parameters: dict[str, Any] | None = None) -> list[Any]:
        """Run a write query in a managed transaction."""

        with self.driver.session(database=self.database) as session:
            return session.execute_write(self._tx_run, query, parameters or {})

    def execute_read(self, query: str, parameters: dict[str, Any] | None = None) -> list[Any]:
        """Run a read query in a managed transaction."""

        with self.driver.session(database=self.database) as session:
            return session.execute_read(self._tx_run, query, parameters or {})

    @staticmethod
    def _tx_run(tx: Any, query: str, parameters: dict[str, Any]) -> list[Any]:
        result = tx.run(query, parameters)
        return result.data()

    def get_node_by_id(
        self,
        label: str,
        node_id: Any,
        *,
        id_field: str = "id",
    ) -> dict[str, Any] | None:
        """Get one node by label and identifier property."""

        label_name = quote_identifier(label)
        id_name = quote_identifier(id_field)
        query = f"MATCH (n:{label_name} {{{id_name}: $id}}) RETURN n LIMIT 1"
        rows = self.execute_read(query, {"id": node_id})
        return rows[0]["n"] if rows else None

    def get_nodes(
        self,
        label: str,
        *,
        filters: dict[str, Any] | None = None,
        offset: int = 0,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get nodes by label and optional exact property filters."""

        label_name = quote_identifier(label)
        filters = filters or {}
        clauses = [f"n.{quote_identifier(key)} = $filter_{key}" for key in filters]
        where_clause = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        query = (
            f"MATCH (n:{label_name}){where_clause} "
            "RETURN n SKIP $offset LIMIT $limit"
        )
        params = {f"filter_{key}": value for key, value in filters.items()}
        params.update({"offset": offset, "limit": limit})
        rows = self.execute_read(query, params)
        return [row["n"] for row in rows]

    def create_node(self, label: str, properties: dict[str, Any]) -> dict[str, Any]:
        """Create one node and return it."""

        label_name = quote_identifier(label)
        query = f"CREATE (n:{label_name}) SET n = $properties RETURN n"
        rows = self.execute_write(query, {"properties": properties})
        return rows[0]["n"]

    def merge_node(
        self,
        label: str,
        match_properties: dict[str, Any],
        set_properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Merge one node by match properties and optionally set properties."""

        label_name = quote_identifier(label)
        match_items = [
            f"{quote_identifier(key)}: $match_{key}" for key in match_properties
        ]
        match_clause = ", ".join(match_items)
        query = f"MERGE (n:{label_name} {{{match_clause}}}) SET n += $set_properties RETURN n"
        params = {f"match_{key}": value for key, value in match_properties.items()}
        params["set_properties"] = set_properties or {}
        rows = self.execute_write(query, params)
        return rows[0]["n"]

    def update_node(
        self,
        label: str,
        node_id: Any,
        properties: dict[str, Any],
        *,
        id_field: str = "id",
    ) -> dict[str, Any] | None:
        """Update one node by identifier property and return it."""

        label_name = quote_identifier(label)
        id_name = quote_identifier(id_field)
        query = (
            f"MATCH (n:{label_name} {{{id_name}: $id}}) "
            "SET n += $properties RETURN n"
        )
        rows = self.execute_write(query, {"id": node_id, "properties": properties})
        return rows[0]["n"] if rows else None

    def delete_node(
        self,
        label: str,
        node_id: Any,
        *,
        id_field: str = "id",
        detach: bool = True,
    ) -> int:
        """Delete one node by identifier property and return deleted count."""

        label_name = quote_identifier(label)
        id_name = quote_identifier(id_field)
        delete_clause = "DETACH DELETE n" if detach else "DELETE n"
        query = (
            f"MATCH (n:{label_name} {{{id_name}: $id}}) "
            f"WITH n, count(n) AS deleted_count {delete_clause} RETURN deleted_count"
        )
        rows = self.execute_write(query, {"id": node_id})
        return int(rows[0]["deleted_count"]) if rows else 0

    def create_relationship(
        self,
        start_label: str,
        start_id: Any,
        relationship_type: str,
        end_label: str,
        end_id: Any,
        *,
        start_id_field: str = "id",
        end_id_field: str = "id",
        properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create one relationship between two existing nodes."""

        start_label_name = quote_identifier(start_label)
        end_label_name = quote_identifier(end_label)
        rel_type_name = quote_identifier(relationship_type)
        start_id_name = quote_identifier(start_id_field)
        end_id_name = quote_identifier(end_id_field)
        query = (
            f"MATCH (a:{start_label_name} {{{start_id_name}: $start_id}}) "
            f"MATCH (b:{end_label_name} {{{end_id_name}: $end_id}}) "
            f"CREATE (a)-[r:{rel_type_name}]->(b) SET r = $properties RETURN r"
        )
        rows = self.execute_write(
            query,
            {
                "start_id": start_id,
                "end_id": end_id,
                "properties": properties or {},
            },
        )
        return rows[0]["r"]


class AsyncNeo4jRepo:
    """Small generic repository for common Neo4j async operations."""

    def __init__(self, driver: Any, *, database: str | None = None):
        self.driver = driver
        self.database = database

    async def run(self, query: str, parameters: dict[str, Any] | None = None) -> list[Any]:
        """Run a Cypher query and return all records."""

        async with self.driver.session(database=self.database) as session:
            result = await session.run(query, parameters or {})
            return await result.data()

    async def execute_write(self, query: str, parameters: dict[str, Any] | None = None) -> list[Any]:
        """Run a write query in a managed transaction."""

        async with self.driver.session(database=self.database) as session:
            return await session.execute_write(self._tx_run, query, parameters or {})

    async def execute_read(self, query: str, parameters: dict[str, Any] | None = None) -> list[Any]:
        """Run a read query in a managed transaction."""

        async with self.driver.session(database=self.database) as session:
            return await session.execute_read(self._tx_run, query, parameters or {})

    @staticmethod
    async def _tx_run(tx: Any, query: str, parameters: dict[str, Any]) -> list[Any]:
        result = await tx.run(query, parameters)
        return await result.data()

    async def get_node_by_id(
        self,
        label: str,
        node_id: Any,
        *,
        id_field: str = "id",
    ) -> dict[str, Any] | None:
        """Get one node by label and identifier property."""

        label_name = quote_identifier(label)
        id_name = quote_identifier(id_field)
        query = f"MATCH (n:{label_name} {{{id_name}: $id}}) RETURN n LIMIT 1"
        rows = await self.execute_read(query, {"id": node_id})
        return rows[0]["n"] if rows else None

    async def get_nodes(
        self,
        label: str,
        *,
        filters: dict[str, Any] | None = None,
        offset: int = 0,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get nodes by label and optional exact property filters."""

        label_name = quote_identifier(label)
        filters = filters or {}
        clauses = [f"n.{quote_identifier(key)} = $filter_{key}" for key in filters]
        where_clause = f" WHERE {' AND '.join(clauses)}" if clauses else ""
        query = (
            f"MATCH (n:{label_name}){where_clause} "
            "RETURN n SKIP $offset LIMIT $limit"
        )
        params = {f"filter_{key}": value for key, value in filters.items()}
        params.update({"offset": offset, "limit": limit})
        rows = await self.execute_read(query, params)
        return [row["n"] for row in rows]

    async def create_node(self, label: str, properties: dict[str, Any]) -> dict[str, Any]:
        """Create one node and return it."""

        label_name = quote_identifier(label)
        query = f"CREATE (n:{label_name}) SET n = $properties RETURN n"
        rows = await self.execute_write(query, {"properties": properties})
        return rows[0]["n"]

    async def merge_node(
        self,
        label: str,
        match_properties: dict[str, Any],
        set_properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Merge one node by match properties and optionally set properties."""

        label_name = quote_identifier(label)
        match_items = [
            f"{quote_identifier(key)}: $match_{key}" for key in match_properties
        ]
        match_clause = ", ".join(match_items)
        query = f"MERGE (n:{label_name} {{{match_clause}}}) SET n += $set_properties RETURN n"
        params = {f"match_{key}": value for key, value in match_properties.items()}
        params["set_properties"] = set_properties or {}
        rows = await self.execute_write(
            query,
            params,
        )
        return rows[0]["n"]

    async def update_node(
        self,
        label: str,
        node_id: Any,
        properties: dict[str, Any],
        *,
        id_field: str = "id",
    ) -> dict[str, Any] | None:
        """Update one node by identifier property and return it."""

        label_name = quote_identifier(label)
        id_name = quote_identifier(id_field)
        query = (
            f"MATCH (n:{label_name} {{{id_name}: $id}}) "
            "SET n += $properties RETURN n"
        )
        rows = await self.execute_write(query, {"id": node_id, "properties": properties})
        return rows[0]["n"] if rows else None

    async def delete_node(
        self,
        label: str,
        node_id: Any,
        *,
        id_field: str = "id",
        detach: bool = True,
    ) -> int:
        """Delete one node by identifier property and return deleted count."""

        label_name = quote_identifier(label)
        id_name = quote_identifier(id_field)
        delete_clause = "DETACH DELETE n" if detach else "DELETE n"
        query = (
            f"MATCH (n:{label_name} {{{id_name}: $id}}) "
            f"WITH n, count(n) AS deleted_count {delete_clause} RETURN deleted_count"
        )
        rows = await self.execute_write(query, {"id": node_id})
        return int(rows[0]["deleted_count"]) if rows else 0

    async def create_relationship(
        self,
        start_label: str,
        start_id: Any,
        relationship_type: str,
        end_label: str,
        end_id: Any,
        *,
        start_id_field: str = "id",
        end_id_field: str = "id",
        properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create one relationship between two existing nodes."""

        start_label_name = quote_identifier(start_label)
        end_label_name = quote_identifier(end_label)
        rel_type_name = quote_identifier(relationship_type)
        start_id_name = quote_identifier(start_id_field)
        end_id_name = quote_identifier(end_id_field)
        query = (
            f"MATCH (a:{start_label_name} {{{start_id_name}: $start_id}}) "
            f"MATCH (b:{end_label_name} {{{end_id_name}: $end_id}}) "
            f"CREATE (a)-[r:{rel_type_name}]->(b) SET r = $properties RETURN r"
        )
        rows = await self.execute_write(
            query,
            {
                "start_id": start_id,
                "end_id": end_id,
                "properties": properties or {},
            },
        )
        return rows[0]["r"]


@overload
def create_neo4j_repo(
    driver: Any,
    *,
    async_mode: Literal[True] = True,
    database: str | None = None,
) -> AsyncNeo4jRepo: ...


@overload
def create_neo4j_repo(
    driver: Any,
    *,
    async_mode: Literal[False],
    database: str | None = None,
) -> SyncNeo4jRepo: ...


def create_neo4j_repo(
    driver: Any,
    *,
    async_mode: bool = True,
    database: str | None = None,
) -> AsyncNeo4jRepo | SyncNeo4jRepo:
    """Create a sync or async Neo4j repository."""

    if async_mode:
        return AsyncNeo4jRepo(driver, database=database)
    return SyncNeo4jRepo(driver, database=database)
