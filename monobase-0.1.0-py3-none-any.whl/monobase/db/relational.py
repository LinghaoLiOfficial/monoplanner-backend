from __future__ import annotations

from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass, field
from collections.abc import AsyncIterator, Iterator
from typing import Any, Literal, overload

from monobase.db.exceptions import DatabaseDependencyError


@dataclass(frozen=True)
class SQLDatabaseConfig:
    """Configuration for SQLAlchemy database access."""

    url: str
    async_mode: bool = True
    echo: bool = False
    pool_pre_ping: bool = True
    engine_options: dict[str, Any] = field(default_factory=dict)
    session_options: dict[str, Any] = field(default_factory=dict)


def create_engine_from_config(config: SQLDatabaseConfig) -> Any:
    """Create a SQLAlchemy Engine or AsyncEngine from config."""

    if config.async_mode:
        return create_async_engine_from_config(config)
    return create_sync_engine_from_config(config)


def create_sync_engine_from_config(config: SQLDatabaseConfig) -> Any:
    """Create a SQLAlchemy sync Engine from config."""

    try:
        from sqlalchemy import create_engine
    except ImportError as exc:
        raise DatabaseDependencyError(
            "SQL database support requires SQLAlchemy: install monobase[db]."
        ) from exc

    return create_engine(
        config.url,
        echo=config.echo,
        pool_pre_ping=config.pool_pre_ping,
        **config.engine_options,
    )


def create_async_engine_from_config(config: SQLDatabaseConfig) -> Any:
    """Create a SQLAlchemy AsyncEngine from config."""

    try:
        from sqlalchemy.ext.asyncio import create_async_engine
    except ImportError as exc:
        raise DatabaseDependencyError(
            "SQL database support requires SQLAlchemy: install monobase[db]."
        ) from exc

    return create_async_engine(
        config.url,
        echo=config.echo,
        pool_pre_ping=config.pool_pre_ping,
        **config.engine_options,
    )


def create_sync_session_factory(engine: Any, **session_options: Any) -> Any:
    """Create a sync sessionmaker bound to an Engine."""

    try:
        from sqlalchemy.orm import sessionmaker
    except ImportError as exc:
        raise DatabaseDependencyError(
            "SQL database support requires SQLAlchemy: install monobase[db]."
        ) from exc

    options = {"expire_on_commit": False, **session_options}
    return sessionmaker(engine, **options)


def create_async_session_factory(engine: Any, **session_options: Any) -> Any:
    """Create an async_sessionmaker bound to an AsyncEngine."""

    try:
        from sqlalchemy.ext.asyncio import async_sessionmaker
    except ImportError as exc:
        raise DatabaseDependencyError(
            "SQL database support requires SQLAlchemy: install monobase[db]."
        ) from exc

    options = {"expire_on_commit": False, **session_options}
    return async_sessionmaker(engine, **options)


@overload
def create_session_factory_from_config(config: SQLDatabaseConfig) -> Any: ...


def create_session_factory_from_config(config: SQLDatabaseConfig) -> Any:
    """Create a sync or async engine and session factory in one step."""

    engine = create_engine_from_config(config)
    if config.async_mode:
        return create_async_session_factory(engine, **config.session_options)
    return create_sync_session_factory(engine, **config.session_options)


@contextmanager
def sync_session_scope(session_factory: Any) -> Iterator[Any]:
    """Provide a transactional sync session scope."""

    with session_factory() as session:
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise


@asynccontextmanager
async def async_session_scope(session_factory: Any) -> AsyncIterator[Any]:
    """Provide a transactional async session scope."""

    async with session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


@overload
def session_scope(
    session_factory: Any,
    *,
    async_mode: Literal[False],
) -> Any: ...


@overload
def session_scope(
    session_factory: Any,
    *,
    async_mode: Literal[True] = True,
) -> Any: ...


def session_scope(session_factory: Any, *, async_mode: bool = True) -> Any:
    """Return a sync or async transactional session context manager."""

    if async_mode:
        return async_session_scope(session_factory)
    return sync_session_scope(session_factory)
