from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Generic, Literal, TypeVar, overload

from monobase.db.exceptions import DatabaseDependencyError

ModelType = TypeVar("ModelType")
SQLDialect = Literal["base", "mysql", "postgresql", "postgres"]


def schema_to_dict(schema_obj: Any) -> dict[str, Any]:
    """Convert a Pydantic-like object or mapping into a plain dict."""

    if hasattr(schema_obj, "model_dump"):
        return schema_obj.model_dump(exclude_unset=True)
    return dict(schema_obj)


def _import_sqlalchemy() -> tuple[Any, Any]:
    try:
        from sqlalchemy import func, select
    except ImportError as exc:
        raise DatabaseDependencyError(
            "SQL database support requires optional dependency: install monobase[db] "
            "or install sqlalchemy with a matching async database driver."
        ) from exc
    return select, func


class BaseAsyncSQLRepo(Generic[ModelType]):
    """Generic async SQLAlchemy repository for common relational CRUD operations."""

    def __init__(self, model: type[ModelType]):
        self.model = model

    async def get(self, session: Any, id: Any) -> ModelType | None:
        """Get one row by primary key."""

        return await session.get(self.model, id)

    async def get_by(self, session: Any, **kwargs: Any) -> ModelType | None:
        """Get one row by exact field matches."""

        select, _ = _import_sqlalchemy()
        stmt = select(self.model).filter_by(**kwargs)
        result = await session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_multi(
        self,
        session: Any,
        offset: int = 0,
        limit: int = 100,
    ) -> Sequence[ModelType]:
        """Get rows with offset and limit pagination."""

        select, _ = _import_sqlalchemy()
        stmt = select(self.model).offset(offset).limit(limit)
        result = await session.execute(stmt)
        return result.scalars().all()

    async def get_multi_by(
        self,
        session: Any,
        offset: int = 0,
        limit: int = 100,
        **kwargs: Any,
    ) -> Sequence[ModelType]:
        """Get rows by exact field matches with pagination."""

        select, _ = _import_sqlalchemy()
        stmt = select(self.model).filter_by(**kwargs).offset(offset).limit(limit)
        result = await session.execute(stmt)
        return result.scalars().all()

    async def get_multi_by_in(
        self,
        session: Any,
        field_name: str,
        values: list[Any],
        offset: int = 0,
        limit: int = 100,
    ) -> Sequence[ModelType]:
        """Get rows where one field is in the supplied values."""

        if not values:
            return []

        select, _ = _import_sqlalchemy()
        model_field = getattr(self.model, field_name)
        stmt = select(self.model).where(model_field.in_(values)).offset(offset).limit(limit)
        result = await session.execute(stmt)
        return result.scalars().all()

    async def count(self, session: Any, **kwargs: Any) -> int:
        """Count rows, optionally filtered by exact field matches."""

        select, func = _import_sqlalchemy()
        stmt = select(func.count()).select_from(self.model).filter_by(**kwargs)
        result = await session.execute(stmt)
        return int(result.scalar_one())

    async def exists(self, session: Any, **kwargs: Any) -> bool:
        """Return whether at least one row matches the exact field filters."""

        select, _ = _import_sqlalchemy()
        stmt = select(self.model).filter_by(**kwargs).limit(1)
        result = await session.execute(stmt)
        return result.scalar_one_or_none() is not None

    async def create(self, session: Any, schema_obj: Any) -> ModelType:
        """Create one ORM object from a mapping or Pydantic-like schema."""

        db_obj = self.model(**schema_to_dict(schema_obj))
        session.add(db_obj)
        await session.flush()
        await session.refresh(db_obj)
        return db_obj

    async def create_multi(self, session: Any, schemas_list: list[Any]) -> Sequence[ModelType]:
        """Create many ORM objects."""

        db_objs = [self.model(**schema_to_dict(schema_obj)) for schema_obj in schemas_list]
        if not db_objs:
            return []

        session.add_all(db_objs)
        await session.flush()
        return db_objs

    async def update(self, session: Any, db_obj: ModelType, schema_obj: Any) -> ModelType:
        """Update one ORM object from a mapping or Pydantic-like schema."""

        for field, value in schema_to_dict(schema_obj).items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)

        session.add(db_obj)
        await session.flush()
        await session.refresh(db_obj)
        return db_obj

    async def delete(self, session: Any, id: Any) -> ModelType | None:
        """Delete one row by primary key and return the deleted ORM object."""

        obj = await self.get(session=session, id=id)
        if obj:
            await session.delete(obj)
            await session.flush()
        return obj

    async def upsert(self, session: Any, schema_obj: Any) -> None:
        """Insert or update one row. Implemented by dialect-specific subclasses."""

        raise NotImplementedError("Use MySQLRepo or PostgresRepo for dialect upsert support.")

    async def upsert_multi(self, session: Any, schemas_list: list[Any]) -> None:
        """Insert or update many rows. Implemented by dialect-specific subclasses."""

        raise NotImplementedError("Use MySQLRepo or PostgresRepo for dialect upsert support.")


class BaseSyncSQLRepo(Generic[ModelType]):
    """Generic sync SQLAlchemy repository for common relational CRUD operations."""

    def __init__(self, model: type[ModelType]):
        self.model = model

    def get(self, session: Any, id: Any) -> ModelType | None:
        """Get one row by primary key."""

        return session.get(self.model, id)

    def get_by(self, session: Any, **kwargs: Any) -> ModelType | None:
        """Get one row by exact field matches."""

        select, _ = _import_sqlalchemy()
        stmt = select(self.model).filter_by(**kwargs)
        result = session.execute(stmt)
        return result.scalar_one_or_none()

    def get_multi(
        self,
        session: Any,
        offset: int = 0,
        limit: int = 100,
    ) -> Sequence[ModelType]:
        """Get rows with offset and limit pagination."""

        select, _ = _import_sqlalchemy()
        stmt = select(self.model).offset(offset).limit(limit)
        result = session.execute(stmt)
        return result.scalars().all()

    def get_multi_by(
        self,
        session: Any,
        offset: int = 0,
        limit: int = 100,
        **kwargs: Any,
    ) -> Sequence[ModelType]:
        """Get rows by exact field matches with pagination."""

        select, _ = _import_sqlalchemy()
        stmt = select(self.model).filter_by(**kwargs).offset(offset).limit(limit)
        result = session.execute(stmt)
        return result.scalars().all()

    def get_multi_by_in(
        self,
        session: Any,
        field_name: str,
        values: list[Any],
        offset: int = 0,
        limit: int = 100,
    ) -> Sequence[ModelType]:
        """Get rows where one field is in the supplied values."""

        if not values:
            return []

        select, _ = _import_sqlalchemy()
        model_field = getattr(self.model, field_name)
        stmt = select(self.model).where(model_field.in_(values)).offset(offset).limit(limit)
        result = session.execute(stmt)
        return result.scalars().all()

    def count(self, session: Any, **kwargs: Any) -> int:
        """Count rows, optionally filtered by exact field matches."""

        select, func = _import_sqlalchemy()
        stmt = select(func.count()).select_from(self.model).filter_by(**kwargs)
        result = session.execute(stmt)
        return int(result.scalar_one())

    def exists(self, session: Any, **kwargs: Any) -> bool:
        """Return whether at least one row matches the exact field filters."""

        select, _ = _import_sqlalchemy()
        stmt = select(self.model).filter_by(**kwargs).limit(1)
        result = session.execute(stmt)
        return result.scalar_one_or_none() is not None

    def create(self, session: Any, schema_obj: Any) -> ModelType:
        """Create one ORM object from a mapping or Pydantic-like schema."""

        db_obj = self.model(**schema_to_dict(schema_obj))
        session.add(db_obj)
        session.flush()
        session.refresh(db_obj)
        return db_obj

    def create_multi(self, session: Any, schemas_list: list[Any]) -> Sequence[ModelType]:
        """Create many ORM objects."""

        db_objs = [self.model(**schema_to_dict(schema_obj)) for schema_obj in schemas_list]
        if not db_objs:
            return []

        session.add_all(db_objs)
        session.flush()
        return db_objs

    def update(self, session: Any, db_obj: ModelType, schema_obj: Any) -> ModelType:
        """Update one ORM object from a mapping or Pydantic-like schema."""

        for field, value in schema_to_dict(schema_obj).items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)

        session.add(db_obj)
        session.flush()
        session.refresh(db_obj)
        return db_obj

    def delete(self, session: Any, id: Any) -> ModelType | None:
        """Delete one row by primary key and return the deleted ORM object."""

        obj = self.get(session=session, id=id)
        if obj:
            session.delete(obj)
            session.flush()
        return obj

    def upsert(self, session: Any, schema_obj: Any) -> None:
        """Insert or update one row. Implemented by dialect-specific subclasses."""

        raise NotImplementedError("Use SyncMySQLRepo or SyncPostgresRepo for dialect upsert support.")

    def upsert_multi(self, session: Any, schemas_list: list[Any]) -> None:
        """Insert or update many rows. Implemented by dialect-specific subclasses."""

        raise NotImplementedError("Use SyncMySQLRepo or SyncPostgresRepo for dialect upsert support.")


class AsyncMySQLRepo(BaseAsyncSQLRepo[ModelType]):
    """SQLAlchemy async repository with MySQL upsert support."""

    def _build_update_dict(self, stmt: Any, insert_keys: set[str]) -> dict[str, Any]:
        _, func = _import_sqlalchemy()
        update_dict = {
            column.name: column
            for column in stmt.inserted
            if column.name in insert_keys and column.name != "id"
        }
        if hasattr(self.model, "updated_at"):
            update_dict["updated_at"] = func.now()
        return update_dict

    async def upsert(self, session: Any, schema_obj: Any) -> None:
        """Insert one row or update existing row on duplicate key."""

        try:
            from sqlalchemy.dialects.mysql import insert
        except ImportError as exc:
            raise DatabaseDependencyError(
                "MySQL upsert support requires SQLAlchemy: install monobase[db]."
            ) from exc

        schema_data = schema_to_dict(schema_obj)
        stmt = insert(self.model).values(**schema_data)
        update_dict = self._build_update_dict(stmt, set(schema_data.keys()))
        upsert_stmt = stmt.on_duplicate_key_update(**update_dict) if update_dict else stmt
        await session.execute(upsert_stmt)
        await session.flush()

    async def upsert_multi(self, session: Any, schemas_list: list[Any]) -> None:
        """Insert many rows or update existing rows on duplicate key."""

        if not schemas_list:
            return

        try:
            from sqlalchemy.dialects.mysql import insert
        except ImportError as exc:
            raise DatabaseDependencyError(
                "MySQL upsert support requires SQLAlchemy: install monobase[db]."
            ) from exc

        values_list = [schema_to_dict(schema_obj) for schema_obj in schemas_list]
        stmt = insert(self.model).values(values_list)
        update_dict = self._build_update_dict(stmt, set(values_list[0].keys()))
        upsert_stmt = stmt.on_duplicate_key_update(**update_dict) if update_dict else stmt
        await session.execute(upsert_stmt)
        await session.flush()


class SyncMySQLRepo(BaseSyncSQLRepo[ModelType]):
    """SQLAlchemy sync repository with MySQL upsert support."""

    def _build_update_dict(self, stmt: Any, insert_keys: set[str]) -> dict[str, Any]:
        _, func = _import_sqlalchemy()
        update_dict = {
            column.name: column
            for column in stmt.inserted
            if column.name in insert_keys and column.name != "id"
        }
        if hasattr(self.model, "updated_at"):
            update_dict["updated_at"] = func.now()
        return update_dict

    def upsert(self, session: Any, schema_obj: Any) -> None:
        """Insert one row or update existing row on duplicate key."""

        try:
            from sqlalchemy.dialects.mysql import insert
        except ImportError as exc:
            raise DatabaseDependencyError(
                "MySQL upsert support requires SQLAlchemy: install monobase[db]."
            ) from exc

        schema_data = schema_to_dict(schema_obj)
        stmt = insert(self.model).values(**schema_data)
        update_dict = self._build_update_dict(stmt, set(schema_data.keys()))
        upsert_stmt = stmt.on_duplicate_key_update(**update_dict) if update_dict else stmt
        session.execute(upsert_stmt)
        session.flush()

    def upsert_multi(self, session: Any, schemas_list: list[Any]) -> None:
        """Insert many rows or update existing rows on duplicate key."""

        if not schemas_list:
            return

        try:
            from sqlalchemy.dialects.mysql import insert
        except ImportError as exc:
            raise DatabaseDependencyError(
                "MySQL upsert support requires SQLAlchemy: install monobase[db]."
            ) from exc

        values_list = [schema_to_dict(schema_obj) for schema_obj in schemas_list]
        stmt = insert(self.model).values(values_list)
        update_dict = self._build_update_dict(stmt, set(values_list[0].keys()))
        upsert_stmt = stmt.on_duplicate_key_update(**update_dict) if update_dict else stmt
        session.execute(upsert_stmt)
        session.flush()


class AsyncPostgresRepo(BaseAsyncSQLRepo[ModelType]):
    """SQLAlchemy async repository with PostgreSQL upsert support."""

    def __init__(
        self,
        model: type[ModelType],
        *,
        conflict_fields: Sequence[str] | None = None,
        update_excluded_fields: Sequence[str] | None = None,
    ):
        super().__init__(model)
        self.conflict_fields = tuple(conflict_fields or ("id",))
        self.update_excluded_fields = set(update_excluded_fields or ("id",))

    def _build_update_dict(self, stmt: Any, insert_keys: set[str]) -> dict[str, Any]:
        _, func = _import_sqlalchemy()
        update_dict = {
            key: getattr(stmt.excluded, key)
            for key in insert_keys
            if key not in self.update_excluded_fields
        }
        if hasattr(self.model, "updated_at"):
            update_dict["updated_at"] = func.now()
        return update_dict

    async def upsert(self, session: Any, schema_obj: Any) -> None:
        """Insert one row or update existing row on PostgreSQL conflict."""

        try:
            from sqlalchemy.dialects.postgresql import insert
        except ImportError as exc:
            raise DatabaseDependencyError(
                "PostgreSQL upsert support requires SQLAlchemy: install monobase[db]."
            ) from exc

        schema_data = schema_to_dict(schema_obj)
        stmt = insert(self.model).values(**schema_data)
        update_dict = self._build_update_dict(stmt, set(schema_data.keys()))
        upsert_stmt = (
            stmt.on_conflict_do_update(index_elements=self.conflict_fields, set_=update_dict)
            if update_dict
            else stmt.on_conflict_do_nothing(index_elements=self.conflict_fields)
        )
        await session.execute(upsert_stmt)
        await session.flush()

    async def upsert_multi(self, session: Any, schemas_list: list[Any]) -> None:
        """Insert many rows or update existing rows on PostgreSQL conflict."""

        if not schemas_list:
            return

        try:
            from sqlalchemy.dialects.postgresql import insert
        except ImportError as exc:
            raise DatabaseDependencyError(
                "PostgreSQL upsert support requires SQLAlchemy: install monobase[db]."
            ) from exc

        values_list = [schema_to_dict(schema_obj) for schema_obj in schemas_list]
        stmt = insert(self.model).values(values_list)
        update_dict = self._build_update_dict(stmt, set(values_list[0].keys()))
        upsert_stmt = (
            stmt.on_conflict_do_update(index_elements=self.conflict_fields, set_=update_dict)
            if update_dict
            else stmt.on_conflict_do_nothing(index_elements=self.conflict_fields)
        )
        await session.execute(upsert_stmt)
        await session.flush()


class SyncPostgresRepo(BaseSyncSQLRepo[ModelType]):
    """SQLAlchemy sync repository with PostgreSQL upsert support."""

    def __init__(
        self,
        model: type[ModelType],
        *,
        conflict_fields: Sequence[str] | None = None,
        update_excluded_fields: Sequence[str] | None = None,
    ):
        super().__init__(model)
        self.conflict_fields = tuple(conflict_fields or ("id",))
        self.update_excluded_fields = set(update_excluded_fields or ("id",))

    def _build_update_dict(self, stmt: Any, insert_keys: set[str]) -> dict[str, Any]:
        _, func = _import_sqlalchemy()
        update_dict = {
            key: getattr(stmt.excluded, key)
            for key in insert_keys
            if key not in self.update_excluded_fields
        }
        if hasattr(self.model, "updated_at"):
            update_dict["updated_at"] = func.now()
        return update_dict

    def upsert(self, session: Any, schema_obj: Any) -> None:
        """Insert one row or update existing row on PostgreSQL conflict."""

        try:
            from sqlalchemy.dialects.postgresql import insert
        except ImportError as exc:
            raise DatabaseDependencyError(
                "PostgreSQL upsert support requires SQLAlchemy: install monobase[db]."
            ) from exc

        schema_data = schema_to_dict(schema_obj)
        stmt = insert(self.model).values(**schema_data)
        update_dict = self._build_update_dict(stmt, set(schema_data.keys()))
        upsert_stmt = (
            stmt.on_conflict_do_update(index_elements=self.conflict_fields, set_=update_dict)
            if update_dict
            else stmt.on_conflict_do_nothing(index_elements=self.conflict_fields)
        )
        session.execute(upsert_stmt)
        session.flush()

    def upsert_multi(self, session: Any, schemas_list: list[Any]) -> None:
        """Insert many rows or update existing rows on PostgreSQL conflict."""

        if not schemas_list:
            return

        try:
            from sqlalchemy.dialects.postgresql import insert
        except ImportError as exc:
            raise DatabaseDependencyError(
                "PostgreSQL upsert support requires SQLAlchemy: install monobase[db]."
            ) from exc

        values_list = [schema_to_dict(schema_obj) for schema_obj in schemas_list]
        stmt = insert(self.model).values(values_list)
        update_dict = self._build_update_dict(stmt, set(values_list[0].keys()))
        upsert_stmt = (
            stmt.on_conflict_do_update(index_elements=self.conflict_fields, set_=update_dict)
            if update_dict
            else stmt.on_conflict_do_nothing(index_elements=self.conflict_fields)
        )
        session.execute(upsert_stmt)
        session.flush()


@overload
def create_sql_repo(
    model: type[ModelType],
    *,
    dialect: SQLDialect = "base",
    async_mode: Literal[True] = True,
    conflict_fields: Sequence[str] | None = None,
    update_excluded_fields: Sequence[str] | None = None,
) -> BaseAsyncSQLRepo[ModelType]: ...


@overload
def create_sql_repo(
    model: type[ModelType],
    *,
    dialect: SQLDialect = "base",
    async_mode: Literal[False],
    conflict_fields: Sequence[str] | None = None,
    update_excluded_fields: Sequence[str] | None = None,
) -> BaseSyncSQLRepo[ModelType]: ...


def create_sql_repo(
    model: type[ModelType],
    *,
    dialect: SQLDialect = "base",
    async_mode: bool = True,
    conflict_fields: Sequence[str] | None = None,
    update_excluded_fields: Sequence[str] | None = None,
) -> BaseAsyncSQLRepo[ModelType] | BaseSyncSQLRepo[ModelType]:
    """Create a sync or async SQL repository by dialect."""

    normalized = "postgresql" if dialect == "postgres" else dialect
    if async_mode:
        if normalized == "mysql":
            return AsyncMySQLRepo(model)
        if normalized == "postgresql":
            return AsyncPostgresRepo(
                model,
                conflict_fields=conflict_fields,
                update_excluded_fields=update_excluded_fields,
            )
        return BaseAsyncSQLRepo(model)

    if normalized == "mysql":
        return SyncMySQLRepo(model)
    if normalized == "postgresql":
        return SyncPostgresRepo(
            model,
            conflict_fields=conflict_fields,
            update_excluded_fields=update_excluded_fields,
        )
    return BaseSyncSQLRepo(model)


# Backward-compatible async names.
BaseSQLRepo = BaseAsyncSQLRepo
MySQLRepo = AsyncMySQLRepo
PostgresRepo = AsyncPostgresRepo
