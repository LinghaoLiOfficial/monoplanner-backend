from __future__ import annotations

from dataclasses import dataclass

from monobase.common import RetryConfig, get_retry, run_with_retry


class TemporaryRemoteError(Exception):
    """Raised when the simulated remote service fails temporarily."""


@dataclass
class UnstableInventoryService:
    failures_before_success: int
    calls: int = 0

    def fetch_stock(self, sku: str) -> dict[str, int | str]:
        self.calls += 1
        print(f"fetch_stock attempt {self.calls}")
        if self.calls <= self.failures_before_success:
            raise TemporaryRemoteError("inventory service is temporarily unavailable")
        return {"sku": sku, "stock": 42}


def check_run_with_retry() -> None:
    service = UnstableInventoryService(failures_before_success=2)

    result = run_with_retry(
        service.fetch_stock,
        "SKU-001",
        exception=TemporaryRemoteError,
        config=RetryConfig(max_attempts=3, wait_seconds=0),
    )

    assert result == {"sku": "SKU-001", "stock": 42}
    assert service.calls == 3
    print("run_with_retry: passed")


def check_get_retry() -> None:
    service = UnstableInventoryService(failures_before_success=1)
    retrying = get_retry(TemporaryRemoteError, max_attempts=2, wait_seconds=0)

    result = retrying(service.fetch_stock, "SKU-002")

    assert result == {"sku": "SKU-002", "stock": 42}
    assert service.calls == 2
    print("get_retry: passed")


def main() -> None:
    check_run_with_retry()
    check_get_retry()
    print("Retry business check completed.")


if __name__ == "__main__":
    main()
