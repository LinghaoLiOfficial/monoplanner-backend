from __future__ import annotations

from monobase.db import Neo4jConfig, create_neo4j_driver, create_neo4j_repo


async def neo4j_example():
    config = Neo4jConfig(
        uri="neo4j://127.0.0.1:7687",
        auth=("neo4j", "password"),
        async_mode=True,
    )
    driver = create_neo4j_driver(config)
    repo = create_neo4j_repo(driver, async_mode=config.async_mode)

    try:
        user = await repo.merge_node(
            "User",
            {"id": "u_001"},
            {"name": "Alice", "email": "alice@example.com"},
        )
        await repo.create_relationship(
            "User",
            "u_001",
            "KNOWS",
            "User",
            "u_002",
            properties={"source": "example"},
        )
        return user
    finally:
        await driver.close()


def neo4j_sync_example():
    config = Neo4jConfig(
        uri="neo4j://127.0.0.1:7687",
        auth=("neo4j", "password"),
        async_mode=False,
    )
    driver = create_neo4j_driver(config)
    repo = create_neo4j_repo(driver, async_mode=config.async_mode)

    try:
        user = repo.merge_node(
            "User",
            {"id": "u_001"},
            {"name": "Alice", "email": "alice@example.com"},
        )
        repo.create_relationship(
            "User",
            "u_001",
            "KNOWS",
            "User",
            "u_002",
            properties={"source": "example"},
        )
        return user
    finally:
        driver.close()
