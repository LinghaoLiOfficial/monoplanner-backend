from __future__ import annotations

from monobase.db import SQLDatabaseConfig, create_session_factory_from_config, create_sql_repo, session_scope


# 业务项目中通常会从自己的 ORM 模块导入 User：
# from app.models import User
User = None


async def create_user_example():
    config = SQLDatabaseConfig(
        url="mysql+asyncmy://user:password@127.0.0.1:3306/app",
        async_mode=True,
        echo=False,
    )
    session_factory = create_session_factory_from_config(config)
    repo = create_sql_repo(User, dialect="mysql", async_mode=config.async_mode)

    async with session_scope(session_factory, async_mode=config.async_mode) as session:
        user = await repo.create(session, {"name": "Alice", "email": "alice@example.com"})
        await repo.upsert(session, {"id": user.id, "name": "Alice", "email": "alice@example.com"})
        return user


def create_user_sync_example():
    config = SQLDatabaseConfig(
        url="mysql+pymysql://user:password@127.0.0.1:3306/app",
        async_mode=False,
        echo=False,
    )
    session_factory = create_session_factory_from_config(config)
    repo = create_sql_repo(User, dialect="mysql", async_mode=config.async_mode)

    with session_scope(session_factory, async_mode=config.async_mode) as session:
        user = repo.create(session, {"name": "Alice", "email": "alice@example.com"})
        repo.upsert(session, {"id": user.id, "name": "Alice", "email": "alice@example.com"})
        return user
