from pathlib import Path

from monobase.llm import PromptFactory, SchemaValidationError


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROMPT_ROOT = PROJECT_ROOT / "prompts"


PROMPT_CASES = {
    "summary": {
        "input": {"user_input": "这是一段关于通用大模型 API 模块设计的说明文字。"},
        "mock_output": {
            "summary": "通用大模型 API 模块需要清晰的模板、配置和校验设计。",
            "keywords": ["大模型", "API", "模板"],
        },
    },
    "extract_info": {
        "input": {
            "user_input": "2026年6月21日，某公司宣布张三担任新项目负责人。",
            "context": "科技新闻",
        },
        "mock_output": {
            "names": ["某公司", "张三"],
            "dates": ["2026年6月21日"],
            "facts": ["某公司宣布张三担任新项目负责人"],
        },
    },
    "classify": {
        "input": {
            "user_input": "这是一条关于产品发布的新闻。",
            "labels": ["新闻", "评论", "广告"],
        },
        "mock_output": {"label": "新闻", "confidence": 0.9},
    },
}


def run_prompt_template_check(prompt_name: str, payload: dict) -> None:
    factory = PromptFactory(PROMPT_ROOT)
    template = factory.load(prompt_name)

    input_data = payload["input"]
    mock_output = payload["mock_output"]

    template.validate_input(input_data)
    rendered_prompt = template.render(input_data)
    template.validate(mock_output)

    print(f"\n[{prompt_name}] OK")
    print("- input_schema.json: passed")
    print("- prompt.j2: rendered")
    print("- output_schema.json: passed")
    print("- rendered preview:")
    print(rendered_prompt[:500])


def main() -> None:
    print(f"Prompt root: {PROMPT_ROOT}")
    for prompt_name, payload in PROMPT_CASES.items():
        try:
            run_prompt_template_check(prompt_name, payload)
        except SchemaValidationError as exc:
            print(f"\n[{prompt_name}] schema validation failed: {exc}")
            raise


if __name__ == "__main__":
    main()

