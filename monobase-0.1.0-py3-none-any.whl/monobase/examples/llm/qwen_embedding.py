import os
from pathlib import Path

from monobase.common import load_project_env
from monobase.llm import LLMClientFactory, LLMConfig, ModelType


def main() -> None:
    load_project_env(Path(__file__))
    model_name = "text-embedding-v4"
    config = LLMConfig(
        base_url=os.environ["QWEN_BASE_URL"],
        api_key=os.environ["QWEN_API_KEY"],
        model=model_name,
        model_type=ModelType.EMBEDDING,
        timeout=60,
    )
    client = LLMClientFactory.create(config)

    vectors = client.invoke(input_texts=["文本1", "文本2"])
    print(f"vector_count={len(vectors)}")
    print(f"first_vector_dim={len(vectors[0])}")


if __name__ == "__main__":
    main()
