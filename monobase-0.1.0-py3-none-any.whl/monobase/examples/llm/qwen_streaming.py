import os
from pathlib import Path

from monobase.common import load_project_env
from monobase.llm import LLMClientFactory, LLMConfig, ModelType, PromptFactory


def main() -> None:
    load_project_env(Path(__file__))
    model_name = "qwen-plus"
    config = LLMConfig(
        base_url=os.environ["QWEN_BASE_URL"],
        api_key=os.environ["QWEN_API_KEY"],
        model=model_name,
        model_type=ModelType.TEXT,
        stream=True,
    )
    prompts = PromptFactory(Path(__file__).resolve().parents[2] / "prompts")
    client = LLMClientFactory.create(config, prompt_factory=prompts)

    for chunk in client.invoke(
        prompt_template="summary",
        variables={"user_input": "请演示 streaming 输出。"},
        stream=True,
        thinking=False,
    ):
        print(chunk, end="", flush=True)


if __name__ == "__main__":
    main()
