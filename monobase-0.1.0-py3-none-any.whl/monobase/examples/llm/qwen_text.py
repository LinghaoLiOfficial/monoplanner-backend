import os
from pathlib import Path

from monobase.common import load_project_env
from monobase.llm import LLMClientFactory, LLMConfig, ModelType, PromptFactory


def main() -> None:
    load_project_env(Path(__file__))
    model_name = "qwen-plus"
    config = LLMConfig(
        base_url=os.environ["QWEN_BASE_URL"],
        api_key=os.environ["QWEN_API_KEY"],
        model=model_name,
        model_type=ModelType.TEXT,
        temperature=0.2,
        timeout=60,
    )
    prompts = PromptFactory(Path(__file__).resolve().parents[2] / "prompts")
    client = LLMClientFactory.create(config, prompt_factory=prompts)

    result = client.invoke(
        prompt_template="summary",
        variables={"user_input": "通用大模型 API 模块需要兼顾可扩展性、可测试性和清晰错误处理。"},
        stream=False,
        thinking=False,
    )
    print(result)


if __name__ == "__main__":
    main()
