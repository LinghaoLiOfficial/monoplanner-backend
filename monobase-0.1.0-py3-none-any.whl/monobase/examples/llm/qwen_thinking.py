import os
from pathlib import Path

from monobase.common import load_project_env
from monobase.llm import LLMClientFactory, LLMConfig, ModelType, PromptFactory


def build_client(thinking: bool):
    load_project_env(Path(__file__))
    model_name = "qwen3.5-plus"
    config = LLMConfig(
        base_url=os.environ["QWEN_BASE_URL"],
        api_key=os.environ["QWEN_API_KEY"],
        model=model_name,
        model_type=ModelType.TEXT,
        thinking=thinking,
    )
    prompts = PromptFactory(Path(__file__).resolve().parents[2] / "prompts")
    return LLMClientFactory.create(config, prompt_factory=prompts)


def main() -> None:
    variables = {"user_input": "比较非流式和 thinking 模式的适用场景。"}

    thinking_off = build_client(thinking=False)
    print(thinking_off.invoke(prompt_template="summary", variables=variables, thinking=False))

    thinking_on = build_client(thinking=True)
    print(thinking_on.invoke(prompt_template="summary", variables=variables, thinking=True))


if __name__ == "__main__":
    main()
