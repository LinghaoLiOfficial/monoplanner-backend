from __future__ import annotations

import json
from abc import ABC, abstractmethod
from collections.abc import Generator, Iterable
from typing import Any

import httpx

from monobase.llm.config import LLMConfig, ModelType
from monobase.llm.exceptions import (
    APIRequestError,
    ModelResponseError,
    StreamingError,
    UnsupportedModelTypeError,
)
from monobase.llm.prompts import PromptFactory, PromptTemplate


class BaseLLMClient(ABC):
    """Common interface implemented by concrete LLM clients."""

    def __init__(self, config: LLMConfig, http_client: httpx.Client | None = None) -> None:
        self.config = config
        self.http_client = http_client or httpx.Client(timeout=config.timeout)
        self._owns_http_client = http_client is None

    @abstractmethod
    def invoke(self, *args: Any, **kwargs: Any) -> Any:
        """Invoke the configured model."""

    def close(self) -> None:
        if self._owns_http_client:
            self.http_client.close()

    def __enter__(self) -> BaseLLMClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    @property
    def headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

    def _endpoint(self, suffix: str) -> str:
        base_url = self.config.base_url.rstrip("/")
        if base_url.endswith(suffix):
            return base_url
        return f"{base_url}/{suffix}"


class TextLLMClient(BaseLLMClient):
    """Client for chat/text LLM APIs using an OpenAI-compatible payload shape."""

    def __init__(
        self,
        config: LLMConfig,
        prompt_factory: PromptFactory | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        super().__init__(config=config, http_client=http_client)
        self.prompt_factory = prompt_factory

    def invoke(
        self,
        prompt_template: str | PromptTemplate | None = None,
        variables: dict[str, Any] | None = None,
        messages: list[dict[str, str]] | None = None,
        stream: bool | None = None,
        thinking: bool | None = None,
        validate_input: bool = True,
        validate_output: bool = True,
    ) -> Any:
        use_stream = self.config.stream if stream is None else stream
        if use_stream:
            return self.invoke_stream(
                prompt_template=prompt_template,
                variables=variables,
                messages=messages,
                thinking=thinking,
                validate_input=validate_input,
                validate_output=validate_output,
            )

        template, rendered_messages = self._prepare_messages(prompt_template, variables, messages, validate_input)
        payload = self._build_payload(
            messages=rendered_messages,
            stream=False,
            thinking=self.config.thinking if thinking is None else thinking,
        )
        data = self._post_json(self._endpoint("chat/completions"), payload)
        content = self._extract_content(data)
        return self._parse_and_validate(content, template, validate_output)

    def invoke_stream(
        self,
        prompt_template: str | PromptTemplate | None = None,
        variables: dict[str, Any] | None = None,
        messages: list[dict[str, str]] | None = None,
        thinking: bool | None = None,
        validate_input: bool = True,
        validate_output: bool = True,
    ) -> Generator[str, None, None]:
        _, rendered_messages = self._prepare_messages(prompt_template, variables, messages, validate_input)
        payload = self._build_payload(
            messages=rendered_messages,
            stream=True,
            thinking=self.config.thinking if thinking is None else thinking,
        )
        try:
            with self.http_client.stream(
                "POST",
                self._endpoint("chat/completions"),
                headers=self.headers,
                json=payload,
                timeout=self.config.timeout,
            ) as response:
                response.raise_for_status()
                for line in response.iter_lines():
                    chunk = self._parse_stream_line(line)
                    if chunk:
                        yield chunk
        except httpx.TimeoutException as exc:
            raise StreamingError("Streaming request timed out.") from exc
        except httpx.HTTPStatusError as exc:
            raise StreamingError(f"Streaming request failed: {exc.response.status_code}") from exc
        except httpx.HTTPError as exc:
            raise StreamingError(f"Streaming request failed: {exc}") from exc

    def _prepare_messages(
        self,
        prompt_template: str | PromptTemplate | None,
        variables: dict[str, Any] | None,
        messages: list[dict[str, str]] | None,
        validate_input: bool,
    ) -> tuple[PromptTemplate | None, list[dict[str, str]]]:
        if messages is not None:
            return None, messages
        template = self._resolve_prompt_template(prompt_template)
        if template is None:
            raise ModelResponseError("Either messages or prompt_template must be provided.")
        rendered_prompt = template.render(variables or {}, validate_input=validate_input)
        return template, [{"role": "user", "content": rendered_prompt}]

    def _resolve_prompt_template(self, prompt_template: str | PromptTemplate | None) -> PromptTemplate | None:
        if isinstance(prompt_template, PromptTemplate):
            return prompt_template
        if isinstance(prompt_template, str):
            if self.prompt_factory is None:
                raise ModelResponseError("prompt_factory is required when prompt_template is a name.")
            return self.prompt_factory.load(prompt_template)
        return None

    def _build_payload(self, messages: list[dict[str, str]], stream: bool, thinking: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": messages,
            "stream": stream,
            **self.config.request_params(),
        }
        if thinking:
            payload["enable_thinking"] = True
        else:
            payload["enable_thinking"] = False
        return payload

    def _post_json(self, url: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            response = self.http_client.post(url, headers=self.headers, json=payload, timeout=self.config.timeout)
            response.raise_for_status()
            return response.json()
        except httpx.TimeoutException as exc:
            raise APIRequestError("API request timed out.") from exc
        except httpx.HTTPStatusError as exc:
            raise APIRequestError(f"API request failed: {exc.response.status_code} {exc.response.text}") from exc
        except httpx.HTTPError as exc:
            raise APIRequestError(f"API request failed: {exc}") from exc
        except json.JSONDecodeError as exc:
            raise ModelResponseError("API response is not valid JSON.") from exc

    def _extract_content(self, data: dict[str, Any]) -> str:
        try:
            choice = data["choices"][0]
            if "message" in choice:
                return str(choice["message"]["content"])
            if "text" in choice:
                return str(choice["text"])
        except (KeyError, IndexError, TypeError) as exc:
            raise ModelResponseError("API response does not contain text content.") from exc
        raise ModelResponseError("API response does not contain text content.")

    def _parse_and_validate(self, content: str, template: PromptTemplate | None, validate_output: bool) -> Any:
        if template is None or not validate_output:
            return content
        try:
            parsed = json.loads(content)
        except json.JSONDecodeError as exc:
            raise ModelResponseError("Model output is not valid JSON.") from exc
        template.validate(parsed)
        return parsed

    def _parse_stream_line(self, line: str) -> str | None:
        if not line:
            return None
        if line.startswith("data:"):
            line = line[5:].strip()
        if line == "[DONE]":
            return None
        try:
            data = json.loads(line)
        except json.JSONDecodeError as exc:
            raise StreamingError(f"Streaming chunk is not valid JSON: {line}") from exc
        try:
            choice = data["choices"][0]
            delta = choice.get("delta", {})
            content = delta.get("content")
            if content is not None:
                return str(content)
            if "text" in choice:
                return str(choice["text"])
        except (KeyError, IndexError, TypeError) as exc:
            raise StreamingError("Streaming chunk has an unsupported shape.") from exc
        return None


class EmbeddingLLMClient(BaseLLMClient):
    """Client for embedding APIs using an OpenAI-compatible payload shape."""

    def invoke(self, input_texts: str | Iterable[str], **_: Any) -> list[float] | list[list[float]]:
        is_single_input = isinstance(input_texts, str)
        texts = input_texts if is_single_input else list(input_texts)
        payload = {
            "model": self.config.model,
            "input": texts,
            **self.config.request_params(),
        }
        data = self._post_json(self._endpoint("embeddings"), payload)
        vectors = self._extract_embeddings(data)
        return vectors[0] if is_single_input else vectors

    def _post_json(self, url: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            response = self.http_client.post(url, headers=self.headers, json=payload, timeout=self.config.timeout)
            response.raise_for_status()
            return response.json()
        except httpx.TimeoutException as exc:
            raise APIRequestError("Embedding API request timed out.") from exc
        except httpx.HTTPStatusError as exc:
            raise APIRequestError(f"Embedding API request failed: {exc.response.status_code}") from exc
        except httpx.HTTPError as exc:
            raise APIRequestError(f"Embedding API request failed: {exc}") from exc
        except json.JSONDecodeError as exc:
            raise ModelResponseError("Embedding API response is not valid JSON.") from exc

    def _extract_embeddings(self, data: dict[str, Any]) -> list[list[float]]:
        try:
            rows = sorted(data["data"], key=lambda item: item.get("index", 0))
            vectors = [row["embedding"] for row in rows]
        except (KeyError, TypeError) as exc:
            raise ModelResponseError("Embedding API response does not contain embedding vectors.") from exc
        if not all(isinstance(vector, list) for vector in vectors):
            raise ModelResponseError("Embedding vectors must be lists.")
        return vectors


class LLMClientFactory:
    """Creates the correct client implementation for the configured model type."""

    @staticmethod
    def create(
        config: LLMConfig,
        prompt_factory: PromptFactory | None = None,
        http_client: httpx.Client | None = None,
    ) -> BaseLLMClient:
        if config.model_type == ModelType.TEXT:
            return TextLLMClient(config=config, prompt_factory=prompt_factory, http_client=http_client)
        if config.model_type == ModelType.EMBEDDING:
            return EmbeddingLLMClient(config=config, http_client=http_client)
        raise UnsupportedModelTypeError(f"Unsupported model_type: {config.model_type}")
