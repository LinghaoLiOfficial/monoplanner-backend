from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from monobase.llm.exceptions import ConfigurationError


class ModelType(str, Enum):
    TEXT = "text"
    EMBEDDING = "embedding"


@dataclass
class LLMConfig:
    """Runtime configuration shared by text and embedding clients."""

    base_url: str
    api_key: str
    model: str
    model_type: ModelType | str
    stream: bool = False
    thinking: bool = False
    temperature: float | None = None
    top_p: float | None = None
    timeout: float = 30.0
    max_tokens: int | None = None
    extra_params: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.base_url:
            raise ConfigurationError("API base_url is required.")
        if not self.api_key:
            raise ConfigurationError("API api_key is required.")
        if not self.model:
            raise ConfigurationError("Model name is required.")

        try:
            self.model_type = ModelType(self.model_type)
        except ValueError as exc:
            raise ConfigurationError(f"Unsupported model_type: {self.model_type}") from exc

    def request_params(self) -> dict[str, Any]:
        params: dict[str, Any] = dict(self.extra_params)
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.max_tokens is not None:
            params["max_tokens"] = self.max_tokens
        return params
