class LLMError(Exception):
    """Base exception for the LLM API module."""


class ConfigurationError(LLMError):
    """Raised when required client configuration is missing or invalid."""


class UnsupportedModelTypeError(ConfigurationError):
    """Raised when no client implementation supports a configured model type."""


class PromptTemplateError(LLMError):
    """Raised when prompt files are missing or malformed."""


class PromptRenderError(PromptTemplateError):
    """Raised when Jinja2 rendering fails."""


class SchemaValidationError(LLMError):
    """Raised when JSON schema loading or output validation fails."""


class ModelResponseError(LLMError):
    """Raised when the model response cannot be parsed as expected."""


class APIRequestError(LLMError):
    """Raised when the remote API request fails."""


class StreamingError(APIRequestError):
    """Raised when a streaming response is interrupted or malformed."""

