from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from jinja2 import StrictUndefined, Template, TemplateError
from jsonschema import Draft202012Validator, FormatChecker, SchemaError, ValidationError

from monobase.llm.exceptions import PromptRenderError, PromptTemplateError, SchemaValidationError


@dataclass
class PromptTemplate:
    """A named Jinja2 prompt plus JSON Schemas for input variables and model output."""

    name: str
    template_text: str
    schema: dict[str, Any]
    input_schema: dict[str, Any] = field(default_factory=lambda: {"type": "object"})
    output_schema: dict[str, Any] = field(init=False)
    _input_schema_validator: Draft202012Validator = field(init=False, repr=False)
    _schema_validator: Draft202012Validator = field(init=False, repr=False)

    def __post_init__(self) -> None:
        try:
            Draft202012Validator.check_schema(self.input_schema)
            Draft202012Validator.check_schema(self.schema)
        except SchemaError as exc:
            raise SchemaValidationError(f"Schema for prompt '{self.name}' is invalid: {exc.message}") from exc
        self.output_schema = self.schema
        self._input_schema_validator = Draft202012Validator(self.input_schema, format_checker=FormatChecker())
        self._schema_validator = Draft202012Validator(self.schema, format_checker=FormatChecker())

    def render(self, variables: dict[str, Any], *, validate_input: bool = True) -> str:
        if validate_input:
            self.validate_input(variables)
        try:
            template = Template(self.template_text, undefined=StrictUndefined)
            return template.render(**variables)
        except TemplateError as exc:
            raise PromptRenderError(f"Failed to render prompt template '{self.name}': {exc}") from exc

    def validate_input(self, variables: dict[str, Any]) -> None:
        try:
            self._input_schema_validator.validate(variables)
        except ValidationError as exc:
            raise SchemaValidationError(
                f"Prompt input does not match schema for prompt '{self.name}': {exc.message}"
            ) from exc

    def validate(self, result: Any) -> None:
        try:
            self._schema_validator.validate(result)
        except ValidationError as exc:
            raise SchemaValidationError(
                f"Model output does not match schema for prompt '{self.name}': {exc.message}"
            ) from exc


class PromptFactory:
    """Loads prompt templates from a directory of per-prompt folders."""

    def __init__(self, prompt_dir: str | Path) -> None:
        self.prompt_dir = Path(prompt_dir)

    def load(self, name: str) -> PromptTemplate:
        prompt_path = self.prompt_dir / name / "prompt.j2"
        input_schema_path = self.prompt_dir / name / "input_schema.json"
        output_schema_path = self.prompt_dir / name / "output_schema.json"
        if not prompt_path.exists():
            raise PromptTemplateError(f"Prompt template file not found: {prompt_path}")
        if not input_schema_path.exists():
            raise PromptTemplateError(f"Prompt input schema file not found: {input_schema_path}")
        if not output_schema_path.exists():
            raise PromptTemplateError(f"Prompt output schema file not found: {output_schema_path}")

        try:
            template_text = prompt_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise PromptTemplateError(f"Failed to read prompt file: {prompt_path}") from exc

        input_schema = self._load_schema(input_schema_path, "input")
        schema = self._load_schema(output_schema_path, "output")

        return PromptTemplate(name=name, template_text=template_text, input_schema=input_schema, schema=schema)

    def load_all(self) -> dict[str, PromptTemplate]:
        if not self.prompt_dir.exists():
            raise PromptTemplateError(f"Prompt directory not found: {self.prompt_dir}")
        templates: dict[str, PromptTemplate] = {}
        for path in sorted(self.prompt_dir.iterdir()):
            if path.is_dir():
                templates[path.name] = self.load(path.name)
        return templates

    def _load_schema(self, schema_path: Path, schema_kind: str) -> dict[str, Any]:
        try:
            return json.loads(schema_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise SchemaValidationError(f"Prompt {schema_kind} schema is not valid JSON: {schema_path}") from exc
        except OSError as exc:
            raise PromptTemplateError(f"Failed to read {schema_kind} schema file: {schema_path}") from exc
