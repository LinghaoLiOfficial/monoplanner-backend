# v2.2 最终候选盲审需求

审阅 `packets.json` 中 12 个匿名提示包的 82 个必须显式事实，并填写
`reviews.template.json`。不要查看 `blind-key.json`。

标签规则：

- `consistent`：所有必要端明确表达事实和具体值，且要求可同时成立。
- `contradiction`：两端要求不能同时成立。
- `omission`：至少一个必要端缺少事实或具体值。
- `uncertain`：无法稳定判断。
- `common_error`：两端一致但共同偏离目标事实。

每项填写非空 explanation。`consistent` 引用所有必要端；`contradiction` 和
`common_error` 引用前后端。quote 必须与 `[start, end)` 对应 prompt 逐字一致。

完成后设置 reviewer 和 `human_attestation: true`，另存为 `reviews.json` 并发回。
只有本轮联合生成的显式语义覆盖率和严格成功率均达到 90%，才扩展正式测试集。
