# v2 开发集小范围测试结果

## 测试范围

本轮使用 `chain-01`（item validation）和 `chain-02`（pagination）的 6 个连续步骤，
比较 `rule` 和 `joint` 两种方法，各运行一次，共 12 个单位。v1 数据、v1 结果和原始
测试集均未覆盖或修改。

v2 输入将事实分成：

- `change_facts`：本步骤新增、修改、回退的事实。
- `active_contract_facts`：步骤完成后的当前契约，其中继承事实标记为 `derivable`，
  只有本步骤必须明确同步的事实标记为 `must_be_explicit`。

## 自动测试结果

| 指标 | 结果 |
| --- | ---: |
| 计划单位 | 12 |
| 完成单位 | 12 |
| 生成失败 | 0 |
| 结构有效率 | 100% |
| 必须显式事实总端数 | 164 |
| 已覆盖端数 | 162 |
| 必须显式事实覆盖率 | 98.78% |
| 模型调用 | 6 |
| tokens | 21,872 |
| 提供方报告成本 | 0.03615425 |

规则基线覆盖率为 82/82 = 100%。联合方法覆盖率为 80/82 = 97.56%；唯一缺口出现在
`c01-s3-joint-r1`，事实 `update-omitted-title-revalidate` 的一端未出现 `[FACT:...]`
标记。该缺口是明确的结构覆盖问题，不能计作语义矛盾。

## v1 与 v2 的测量差异

v1 开发集只有 7/18 包可评价，原因主要是继承事实被要求逐项出现在提示中。v2 将 32
个继承事实标为 `derivable`，不再因为没有逐字重述而记为漏项；6 个步骤共 41 个事实
被要求必须显式覆盖。v2 的覆盖率因此可以在不依赖语义盲审的情况下先行检查。

## 语义指标状态

v2 的 `C_evaluable`、`C_observed`、可评价率和严格成功率尚未计算，因为该轮尚未完成
12 个包的盲审。盲审材料在 `review/`：

- `packets.json`
- `reviews.template.json`
- `blind-key.json`（审阅完成前不得打开）

完成审阅后可运行：

```sh
.venv/bin/python -m evals.requirement_eval_v2 report \
  results/v2-dev-pilot-20261003 \
  results/v2-dev-pilot-20261003/report-reviewed.json \
  --reviews results/v2-dev-pilot-20261003/review/reviews.json
```

## 当前判断

v2 已通过协议层的小范围验收：生成完整、结构有效、显式契约覆盖率超过 90%，且继承
事实不再系统性制造漏项。下一步只需完成盲审，确认 v2 的语义矛盾和共同错误指标，再
决定是否把 v2 扩展到 8 条测试链。
